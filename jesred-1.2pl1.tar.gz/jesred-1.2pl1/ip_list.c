/*
 * $Id: ip_list.c,v 1.2 1999/01/23 22:16:11 elkner Exp $
 *
 * Author:  Harvest/Squid derived       http://squid.nlanr.net/Squid/
 * Project: Jesred       http://ivs.cs.uni-magdeburg.de/~elkner/webtools/jesred/
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html or ./gpl.html
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

/*
 * Copyright (c) 1994, 1995.  All rights reserved.
 *  
 *   The Harvest software was developed by the Internet Research Task
 *   Force Research Group on Resource Discovery (IRTF-RD):
 *  
 *         Mic Bowman of Transarc Corporation.
 *         Peter Danzig of the University of Southern California.
 *         Darren R. Hardy of the University of Colorado at Boulder.
 *         Udi Manber of the University of Arizona.
 *         Michael F. Schwartz of the University of Colorado at Boulder.
 *         Duane Wessels of the University of Colorado at Boulder.
 *  
 *   This copyright notice applies to software in the Harvest
 *   ``src/'' directory only.  Users should consult the individual
 *   copyright notices in the ``components/'' subdirectories for
 *   copyright information about other software bundled with the
 *   Harvest source code distribution.
 *  
 * TERMS OF USE
 *   
 *   The Harvest software may be used and re-distributed without
 *   charge, provided that the software origin and research team are
 *   cited in any use of the system.  Most commonly this is
 *   accomplished by including a link to the Harvest Home Page
 *   (http://harvest.cs.colorado.edu/) from the query page of any
 *   Broker you deploy, as well as in the query result pages.  These
 *   links are generated automatically by the standard Broker
 *   software distribution.
 *   
 *   The Harvest software is provided ``as is'', without express or
 *   implied warranty, and with no support nor obligation to assist
 *   in its use, correction, modification or enhancement.  We assume
 *   no liability with respect to the infringement of copyrights,
 *   trade secrets, or any patents, and are not responsible for
 *   consequential damages.  Proper use of the Harvest software is
 *   entirely the responsibility of the user.
 *  
 * DERIVATIVE WORKS
 *  
 *   Users may make derivative works from the Harvest software, subject 
 *   to the following constraints:
 *  
 *     - You must include the above copyright notice and these 
 *       accompanying paragraphs in all forms of derivative works, 
 *       and any documentation and other materials related to such 
 *       distribution and use acknowledge that the software was 
 *       developed at the above institutions.
 *  
 *     - You must notify IRTF-RD regarding your distribution of 
 *       the derivative work.
 *  
 *     - You must clearly notify users that your are distributing 
 *       a modified version and not the original Harvest software.
 *  
 *     - Any derivative product is also subject to these copyright 
 *       and use restrictions.
 *  
 *   Note that the Harvest software is NOT in the public domain.  We
 *   retain copyright, as specified above.
 *  
 * HISTORY OF FREE SOFTWARE STATUS
 *  
 *   Originally we required sites to license the software in cases
 *   where they were going to build commercial products/services
 *   around Harvest.  In June 1995 we changed this policy.  We now
 *   allow people to use the core Harvest software (the code found in
 *   the Harvest ``src/'' directory) for free.  We made this change
 *   in the interest of encouraging the widest possible deployment of
 *   the technology.  The Harvest software is really a reference
 *   implementation of a set of protocols and formats, some of which
 *   we intend to standardize.  We encourage commercial
 *   re-implementations of code complying to this set of standards.  
 */

#ifdef __FreeBSD__
#  include <stddef.h>
#  include <sys/types.h>
#endif /* __FreeBSD__ */

#ifdef LINUX
#  include <stdio.h>
#  include <stdlib.h>
#endif

#include <string.h>

#include <netinet/in.h>
#include <arpa/inet.h>

#include "ip_list.h"
#include "util.h"
#include "log.h"

ip_access_type
ip_access_check(int afamily, const void *address, const ip_acl *list)
{
    const ip_acl *p = NULL;
    struct in_addr h;
    ip_access_type response=IP_DENY;
    int i;
#ifdef DEBUG
    char addrbuffer[INET6_ADDRSTRLEN];

    if (!inet_ntop(afamily,address,addrbuffer,sizeof(addrbuffer)))
       addrbuffer[0]=0;
#endif

    if (list)
    {
       for (p = list; p; p = p->next)
       {
	  if (p->af!=afamily)
	     continue;
	  if (p->af==AF_INET)
	  {
	     h.s_addr = ((struct in_addr *)address)->s_addr & p->mask.s_addr;
	     if (h.s_addr == p->addr.s_addr)
	     {
		response=p->access;
		break;
	     }
	  }
	  else if (p->af==AF_INET6)
	  {
	     int equal=1;
	     /* apply mask and compare byte-wise*/
	     for (i=0;i<sizeof(p->addr6.s6_addr);++i)
	     {
		if (p->addr6.s6_addr[i] !=
		    (((struct in6_addr *)address)->s6_addr[i] & p->mask6.s6_addr[i]))
		{
		   equal=0;
		   break;
		}
	     }
	     if (equal)
	     {
		response=p->access;
		break;
	     }
	  }
       }
    }
#ifdef DEBUG
    mylog(DEBG, "ACL: %s %s\n",
	  response==IP_DENY ? "denied":"allowed",
	  addrbuffer);
#endif
    return response;
}

void
addToIPACL(ip_acl **list, const char *ip_str)
{
    ip_acl *p, *q;
    int inv=0, masklen;
    char *masklenp;
    int family,i;

    if (!ip_str) {
	return;
    }

    /* decode ip address */
    if (*ip_str == '!') {
        ip_str++;
        inv++;
    }
    /* ipv6 or v4? */
    family=strchr(ip_str,':')?AF_INET6:AF_INET;
    /* where's the mask length? */
    masklenp=strchr(ip_str,'/');
    if (!masklenp)
    {
       mylog(ERROR, "Ignoring invalid IP acl line '%s': no mask len\n",ip_str);
       return;
    }
    *masklenp=0;
    masklen=atoi(++masklenp);
    if (masklen<0 || (family==AF_INET6 && masklen>128)
	|| (family==AF_INET && masklen>32))
    {
       mylog(ERROR, "Ignoring invalid IP acl line '%s': bad mask len\n",ip_str);
       return;
    }


    if (! (*list)) {
	/* empty list */
	*list = xcalloc(1, sizeof(ip_acl));
	(*list)->next = NULL;
	q = *list;
	p=NULL;
    } else {
	/* find end of list */
	p = *list;
	while (p->next)
	    p = p->next;
	q = xcalloc(1, sizeof(ip_acl));
	q->next = NULL;
	p->next = q;
    }

    q->af=family;
    /* now parse the address */
    if (!inet_pton(family,ip_str,(family==AF_INET?(void*)&q->addr.s_addr:
				  (void*)&q->addr6.s6_addr)))
    {
       mylog(ERROR, "Ignoring invalid IP acl line '%s'\n",ip_str);
       safe_free(q);
       if (p)
	  p->next=NULL;
       else
	  *list=NULL;
       return;
    }
    /* let's construct the mask and fill in the remaining bits */
    q->access = inv ? IP_DENY : IP_ALLOW;

    if (family==AF_INET)
    {
       q->mask.s_addr= masklen ? htonl(0xfffffffful << (32 - masklen)) : 0;
    }
    else
    {
       for (i=0;i<sizeof(q->mask6.s6_addr);++i)
       {
	  if (i<masklen/8)
	  {
	     q->mask6.s6_addr[i]=0xff;
	  }
	  else if (i>masklen/8)
	  {
	     q->mask6.s6_addr[i]=0;
	  }
	  else
	  {
	     q->mask6.s6_addr[i]=  0xff&(0xff<<(8-masklen%8));
	  }
       }
    }
}

void
ip_acl_destroy(ip_acl **a)
{
    ip_acl *b;
    ip_acl *n;
    for (b = *a; b; b = n) {
	n = b->next;
	safe_free(b);
    }
    *a = NULL;
}

