/*
 * $Id: path.h,v 1.1 1998/07/24 23:03:13 elkner Exp $
 */

#ifndef PATH_H
#define PATH_H

/* change this to the path, which contains your jesred.conf */

#define DEFAULT_PATH "/local/squid/etc"

#endif
