/* $Id: version.h,v 1.2 1998/08/15 03:19:03 elkner Exp $
 *
 * Author:  Jens Elkner  elkner@ivs.cs.uni-magdeburg.de
 * Project: Jesred       http://ivs.cs.uni-magdeburg.de/~elkner/webtools/jesred/
 *
 */

#ifndef VERSION_H
#define VERSION_H

#define APPNAME "JESRED"
#define VERSION "1.2"

#define AUTHOR "Jens Elkner"
#define AUTHOR_EMAIL "elkner@ivs.cs.uni-magdeburg.de"
#define AUTHOR_URL "http://ivs.cs.uni-magdeburg.de/~elkner/"
#define APPURL "http://ivs.cs.uni-magdeburg.de/~elkner/webtools/jesred/"

#endif /* VERSION_H */
